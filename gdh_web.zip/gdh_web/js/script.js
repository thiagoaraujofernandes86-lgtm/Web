(() => {
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Mobile menu
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.menu');

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // Close on link click
    menu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        menu.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      const isClickInside = menu.contains(e.target) || toggle.contains(e.target);
      if (!isClickInside) {
        menu.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Contact form: opens mail client via mailto (no backend)
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = new FormData(form);
      const name = (data.get('name') || '').toString().trim();
      const email = (data.get('email') || '').toString().trim();
      const org = (data.get('org') || '').toString().trim();
      const topic = (data.get('topic') || '').toString().trim();
      const message = (data.get('message') || '').toString().trim();

      const subject = encodeURIComponent(`[GDH] ${topic} — ${name}${org ? ' / ' + org : ''}`);
      const body = encodeURIComponent(
        `Nombre: ${name}\nCorreo: ${email}\nOrganización: ${org || '-'}\nInterés: ${topic}\n\nMensaje:\n${message}\n`
      );

      window.location.href = `mailto:dr.majb@gmail.com?subject=${subject}&body=${body}`;
      form.reset();
    });
  }
})();
