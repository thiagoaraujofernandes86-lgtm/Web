# Global Dental Health — One‑Page Website

Sitio web lineal (one‑page) para **Global Dental Health**, con secciones:
Hero · Quiénes somos · Qué hacemos · Cómo trabajamos · Impacto · Testimonios · Contacto.

## Cómo usar
1) Abre `index.html` en tu navegador.
2) Para desplegar en hosting estático, sube la carpeta completa tal cual.

## Personalización rápida
- Imagen de fondo del Hero: en `css/style.css` (bloque `.hero-bg`) ver comentarios para reemplazar por tu imagen.
- Correo y teléfono: en `index.html`, sección Contacto.
- Impacto/Testimonios: reemplaza los textos “ejemplo” por métricas y citas reales verificadas.
